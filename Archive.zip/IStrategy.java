package mycontroller;
import java.util.ArrayList;
import utilities.Coordinate;
/**
 * IStrategy: interface of optimization strategies 
 * @author christina xu
 *
 */
public interface IStrategy {
	/**
	 * gets the position for explore.
	 */
	public Coordinate getExplorePosition(ArrayList<Coordinate> unexplored, Coordinate target);

	/**
	 * get the weight of the lava
	 * @return lava weight
	 */
	public int getLavaWeight();
}
