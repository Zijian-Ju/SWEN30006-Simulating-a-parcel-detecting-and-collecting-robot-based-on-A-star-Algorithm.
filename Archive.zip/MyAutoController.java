package mycontroller;
import controller.CarController;
import world.Car;
import java.util.HashMap;
import tiles.*;
import utilities.Coordinate;

/**
 * MyAutoController: Automatically runs the car to get parcels and escape.
 * @author christina xu
 */
public class MyAutoController extends CarController{
	private boolean initiate = true;
	//sensor of the controller
	private Sensor sensor;
	//path finder find the path
	private PathFinder pathFinder;
	//path follower follows the path
	private PathFollower pathFollower;
	
	public MyAutoController(Car car) {
		super(car);
		this.pathFinder = new AStarPathFinder();
		this.pathFollower = new PathFollower(pathFinder, this);
		this.sensor = new Sensor(this);
	}
	
	/**
	 * @Override
	 * updates the controller to move the car in certain ways
	 */
	public void update() {
		//initiate the car to move
		if(initiate) {
			applyForwardAcceleration(); 
			initiate = false;
		}
		
		//update the sensor
		HashMap<Coordinate, MapTile> currentview = getView();
		sensor.update(currentview);
		
		//update the path follower
		pathFollower.update();
	}
	

	
	/**
	 * get the current location of the car
	 * @return current coordinate
	 */
	public Coordinate getCurrentCoordinate() {
		Coordinate currentCoor = new Coordinate(getPosition());
		return currentCoor;
	}
	

	/**
	 * get the sensor
	 * @return sensor
	 */
	public Sensor getSensor() {
		return sensor;
	}
	
}
