package mycontroller;
import java.util.ArrayList;
import utilities.Coordinate;

/**
 * Health optimization strategy
 * @author christina xu
 *
 */
public class HealthStrategy implements IStrategy{
	//set a high lava cost
	public final static int LAVA = 50;
	
	/**
	 * @Overrride
	 * gets the location for explore.
	 * For health strategy, always find the nearest unexplored view.
	 */
	public Coordinate getExplorePosition(ArrayList<Coordinate> unexplored, Coordinate current) {	
		int nearestDist = Integer.MAX_VALUE;
		int dist;
		Coordinate nearest = null;
		for(Coordinate target: unexplored) {
			int dx = target.x - current.x;
			int dy = target.y - current.y;
			dist = Math.abs(dx) + Math.abs(dy);
			if(dist < nearestDist) {
				nearest = target;
				nearestDist = dist;
			}
		}
		return nearest;
	}

	
	@Override
	public int getLavaWeight() {
		// TODO Auto-generated method stub
		return LAVA;
	}
	

}
