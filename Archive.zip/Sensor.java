package mycontroller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import tiles.MapTile;
import tiles.TrapTile;
import tiles.MapTile.Type;
import utilities.Coordinate;
import world.World;
import world.WorldSpatial.Direction;

/**
 * Sensor is responsible for looking for map tiles around the car.
 * It updates the explored view and unexplored view.
 * @author christina Xu
 *
 */
public class Sensor {
	//explored view contains map tiles that has been viewed by the car
	private HashMap<Coordinate, MapTile> exploredView;
	//unexplored view contains coordinates that has not been viewed by the car
	private ArrayList<Coordinate> unexploredView = new ArrayList<Coordinate>();
	private MyAutoController controller;
	
	public Sensor(MyAutoController controller) {
		this.controller = controller;
		initializeExploredView();
		initalizeUnexploredView();
	}
	
	public void update(HashMap<Coordinate, MapTile> currentview) {
		updateExploredView(currentview);
		updateUnexploredView(currentview);
	}
	
	/**
	 * initialize the explored view with provided map tiles
	 */
	private void initializeExploredView() {
		exploredView = new HashMap<Coordinate, MapTile>();
		exploredView.putAll(controller.getMap());
	}
	
	/**
	 * initialize the unexplored view contains all coordinates of the map
	 */
	private void initalizeUnexploredView() {
		for(int xPosition = 0 ; xPosition < World.MAP_WIDTH; xPosition++) {
			for(int yPosition = 0 ; yPosition < World.MAP_HEIGHT ; yPosition++) {
				unexploredView.add(new Coordinate(xPosition, yPosition));
			}
		}
	}
	
	/**
	 * updates the viewed map based on current view
	 * @param currentview
	 */
	private void updateExploredView(HashMap<Coordinate, MapTile> currentview) {
		exploredView.putAll(currentview);
	}
	
	/**
	 * removes the coordinates from the unexplored map based on current view
	 * @param currentview
	 */
	private void updateUnexploredView(HashMap<Coordinate, MapTile> currentview) {
		// remove all nodes in the current view from notSeen
		for(Coordinate coor: currentview.keySet()) {
			if(coor.x>=0 && coor.y>=0) {
				if (coor.x < World.MAP_WIDTH && coor.y < World.MAP_HEIGHT) {
					unexploredView.remove(coor);
				}
			}	
		}
	}
	
	/**
	 * removes coordinate from the unexplored view
	 * @param coordinate
	 */
	public void removeUnexploredView(Coordinate coor) {
		unexploredView.remove(coor);
	}
	
	
	public HashMap<Coordinate, MapTile> getExploredView(){
		return exploredView;
	}
	
	public ArrayList<Coordinate> getUnexploredView(){
		return unexploredView;
	}
	
	/**
	 * checks if a wall is in front of the car
	 * @return
	 */
	public boolean checkWallForward() {
		Direction heading = controller.getOrientation();
		Coordinate now = controller.getCurrentCoordinate();
		HashMap<Coordinate, MapTile> map = getExploredView();
		boolean wallAhead = false;
		
		switch(heading) {
		case EAST:
			if(map.get(new Coordinate(now.x+1, now.y)).isType(Type.WALL))
				wallAhead = true;
			break;
		case WEST:
			if(map.get(new Coordinate(now.x-1, now.y)).isType(Type.WALL))
				wallAhead = true;
			break;
		case NORTH:
			if(map.get(new Coordinate(now.x, now.y+1)).isType(Type.WALL))
				wallAhead = true;
			break;
		case SOUTH:
			if(map.get(new Coordinate(now.x, now.y-1)).isType(Type.WALL))
				wallAhead = true;
			break;
		}
		return wallAhead;
	}
	
	/**
	 * gets a list of trap locations based on trap type
	 * @param trapType
	 * @return a list of traps' coordinates
	 */
	public ArrayList<Coordinate> getTrapLocations(String trapType){
		ArrayList<Coordinate> traps = new ArrayList<Coordinate>();
		for (Entry<Coordinate, MapTile> trap : exploredView.entrySet()) {
			if(trap.getValue().isType(Type.TRAP)) {
				TrapTile temp = (TrapTile)trap.getValue();
				if(temp.getTrap().equals(trapType)) {
					traps.add(trap.getKey());
				}
			}
		}
		return traps;
	}
	
	
	/**
	 * gets the exit tile from the explored view
	 * @return the exit
	 */
	public ArrayList<Coordinate> getExit(){
		ArrayList<Coordinate> exit = new ArrayList<Coordinate>();
		for (Entry<Coordinate, MapTile> tile : exploredView.entrySet()) {
			if(tile.getValue().isType(Type.FINISH)) {
				exit.add(tile.getKey());
			}
		}
		return exit;
	}
}
