package mycontroller;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;
import tiles.MapTile;
import tiles.MapTile.Type;
import tiles.TrapTile;
import utilities.Coordinate;

/**
 * AStarPathFinder uses A* algorithm to find the shortest path.
 * The algorithm is written based on the tutorial from Pearson
 * @author christina xu
 */
public class AStarPathFinder extends PathFinder {
	//set max value to tiles that need to be avoided, for example, wall
	private static final double AVOID = Double.MAX_VALUE;
	//health and water are good trap tiles, so the weight is low
	//set neighbor sensibility to 1
	private static final int NEIGHBOR = 1;

	public AStarPathFinder(){
		
	}
	
	/**
	 * construct the path based on current coordinate
	 * @param previous
	 * @param current
	 * @return
	 */
	private ArrayList<Coordinate> constructPath(HashMap<Coordinate, Coordinate> previous, Coordinate current) {
        ArrayList<Coordinate> path = new ArrayList<>();
        path.add(current);
        while (previous.containsKey(current)) {
            current = previous.get(current);
            path.add(current);
        }
        Collections.reverse(path);
        return path;
    }
	
	/**
	 * get the estimated min cost
	 * @param map1
	 * @param map2
	 * @param list
	 * @return
	 */
	private Coordinate getEstimatedCost(HashMap<Coordinate, Double> map1, HashMap<Coordinate, Double> map2, ArrayList<Coordinate> list) {
		double min = Double.MAX_VALUE;
		Coordinate minCoor = null;
		for(int i=0; i<list.size(); i++) {
			double current = map1.get(list.get(i)) + map2.get(list.get(i));
		    if (min > current) {
		    	min = current;
		    	minCoor = list.get(i);
		    }
		}
		return minCoor;
	}
	
	/**
	 * gets the path from between two nodes (A* algorithm)
	 */
	public ArrayList<Coordinate> getPath(HashMap<Coordinate, MapTile> map, Coordinate current, Coordinate target){
		ArrayList<Coordinate> open = new ArrayList<Coordinate>();
		ArrayList<Coordinate> close = new ArrayList<Coordinate>();
		HashMap<Coordinate, Coordinate> previousPath = new HashMap<Coordinate, Coordinate>();
        HashMap<Coordinate, Double> firstMap = new HashMap<Coordinate, Double>();
        firstMap.put(current, 0.0);
        HashMap<Coordinate, Double> secondMap = new HashMap<Coordinate, Double>();
        secondMap.put(current, getAdjacentCost(current, target));    
        open.add(current);   
		
        while (open.size() > 0) {
			Coordinate coor = getEstimatedCost(firstMap, secondMap, open);
			if (coor == null) {
				return null;
			}
        	if (coor.equals(target)) {
                return constructPath(previousPath, coor);  
            }
        	HashMap<Coordinate, String> neighbours = getNeighbours(map, coor);
        	close.add(coor);
        	open.remove(coor);	
        	for (Entry<Coordinate, String> entry : neighbours.entrySet()) {
        		Coordinate neighbour = entry.getKey();
        		String tileType = entry.getValue();
                if (close.contains(neighbour)) {
                    continue;	
                }
                double val = firstMap.get(coor) + getAdjacentCost(coor, neighbour);
				if (!open.contains(neighbour)) {
					open.add(neighbour);
				}
				else if (val > firstMap.get(neighbour)) {
					continue;
				}
				previousPath.put(neighbour, coor);
				avoidWall(tileType, val, firstMap, neighbour);
				secondMap.put(neighbour, getAdjacentCost(neighbour, target)); // update h values
        	}
        }
        return new ArrayList<>();
	}
	
	/**
	 * avoid walls
	 * @param tileType
	 * @param val
	 * @param map
	 * @param coor
	 */
	public void avoidWall(String tileType, double val, HashMap<Coordinate, Double> map, 
			Coordinate coor) {
		if (tileType.equals("WALL")) {
			map.put(coor, AVOID);
		} else {
			map.put(coor, val);
		}
	}
	
	
	

	
	/**
	 * gets the trap tile of a coordinate
	 * @param map
	 * @param coor
	 * @return
	 */
	private String getTrapType(HashMap<Coordinate, MapTile> map, Coordinate coor) {
		MapTile tile = map.get(coor);
		if (tile == null) {
			return "WALL";
		}else {
			if (tile.isType(Type.TRAP)) {
				TrapTile trapTile = (TrapTile) tile;
	        	return trapTile.getTrap(); 
			}else {
				if(tile.isType(Type.EMPTY))
					return "WALL"; 
				return tile.getType().toString(); 
	        }
		}
	}
	
	/**
	 * gets the neighbors of the current location
	 * @param map
	 * @param current coordinate
	 * @return neighbors of the current tile
	 */
	private HashMap<Coordinate, String> getNeighbours(HashMap<Coordinate, MapTile> map, Coordinate current){
		HashMap<Coordinate, String> neighbours = new HashMap<Coordinate, String>();
		Coordinate left = new Coordinate(current.x-NEIGHBOR, current.y);
		neighbours.put(left,getTrapType(map,left));
		Coordinate right = new Coordinate(current.x+NEIGHBOR, current.y);
		neighbours.put(right,getTrapType(map,right));
		Coordinate upward = new Coordinate(current.x, current.y+NEIGHBOR);
		neighbours.put(upward,getTrapType(map,upward));
		Coordinate downward = new Coordinate(current.x, current.y-NEIGHBOR);
		neighbours.put(downward,getTrapType(map,downward));
		
		return neighbours;
	}
	
	/**
	 * gets the cost between two adjacent tiles (Non-weighted)
	 * @param current
	 * @param target
	 * @return
	 */
	private double getAdjacentCost(Coordinate current, Coordinate target) {
		double dx = target.x - current.x;
		double dy = target.y - current.y;
		double dis = Math.abs(dx) + Math.abs(dy);
		return dis;
	}


	
}
