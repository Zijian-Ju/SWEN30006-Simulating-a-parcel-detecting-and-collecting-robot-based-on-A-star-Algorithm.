package mycontroller;
import java.util.ArrayList;
import java.util.HashMap;
import tiles.MapTile;
import utilities.Coordinate;

/**
 * abstract PathFinder: find a path based on an algorithm
 * @author christina xu
 */

public abstract class PathFinder {

	/**
	 * get the path between two nodes
	 * @param map
	 * @param current
	 * @param target
	 * @return path
	 */
	public abstract ArrayList<Coordinate> getPath(HashMap<Coordinate, MapTile> map, 
            Coordinate current, Coordinate target);

	
	
}
